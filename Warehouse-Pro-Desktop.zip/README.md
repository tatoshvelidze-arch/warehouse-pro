# Warehouse-Pro Desktop App v1.0

სრული საწყობის მართვის სისტემა - Desktop ვერსია

## ინსტალაცია 2 წუთში

### Windows / Mac / Linux

1. დააინსტალირე Node.js: https://nodejs.org
2. გახსენი Terminal ამ ფოლდერში
3. გაუშვი:
```bash
npm install
```

### Build ინსტალერი

**Windows (.exe):**
```bash
npm run build-win
```
ფაილი: `dist/Warehouse-Pro Setup 1.0.0.exe`

**Mac (.dmg):**
```bash
npm run build-mac
```

**Linux:**
```bash
npm run build-linux
```

### გაშვება დეველოპმენტში
```bash
npm start
```

## ფუნქციები

✅ 16 მოდული სრულად
✅ ქართული ინტერფეისი
✅ AI ასისტენტი
✅ Offline მუშაობა
✅ Auto-updater
✅ Native menu

Login: admin / admin123
