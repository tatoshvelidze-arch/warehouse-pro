const { app, BrowserWindow, Menu, Tray, nativeImage } = require('electron');
const path = require('path');

let mainWindow;
let tray;

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1400,
    height: 900,
    minWidth: 1200,
    minHeight: 700,
    backgroundColor: '#0A192F',
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true
    },
    icon: path.join(__dirname, 'build/icon.png')
  });

  mainWindow.loadFile('index.html');
  
  // Native menu in Georgian
  const template = [
    {
      label: 'ფაილი',
      submenu: [
        { label: 'ახალი პროდუქტი', accelerator: 'CmdOrCtrl+N', click: () => mainWindow.webContents.send('menu-new-product') },
        { label: 'ექსპორტი', accelerator: 'CmdOrCtrl+E', click: () => mainWindow.webContents.send('menu-export') },
        { type: 'separator' },
        { label: 'გასვლა', accelerator: 'CmdOrCtrl+Q', role: 'quit' }
      ]
    },
    {
      label: 'რედაქტირება',
      submenu: [
        { label: 'გაუქმება', role: 'undo' },
        { label: 'გამეორება', role: 'redo' },
        { type: 'separator' },
        { label: 'ამოჭრა', role: 'cut' },
        { label: 'კოპირება', role: 'copy' },
        { label: 'ჩასმა', role: 'paste' }
      ]
    },
    {
      label: 'ხედი',
      submenu: [
        { label: 'Reload', role: 'reload' },
        { label: 'Toggle DevTools', accelerator: 'F12', role: 'toggleDevTools' },
        { type: 'separator' },
        { label: 'Actual Size', role: 'resetZoom' },
        { label: 'Zoom In', role: 'zoomIn' },
        { label: 'Zoom Out', role: 'zoomOut' },
        { type: 'separator' },
        { label: 'სრული ეკრანი', role: 'togglefullscreen' }
      ]
    },
    {
      label: 'დახმარება',
      submenu: [
        { label: 'შესახებ', click: () => {
          require('electron').dialog.showMessageBox(mainWindow, {
            type: 'info',
            title: 'Warehouse-Pro',
            message: 'Warehouse-Pro v1.0.0',
            detail: 'სრული საწყობის მართვის სისტემა\n16 მოდული | ქართული ინტერფეისი | AI ასისტენტი'
          });
        }}
      ]
    }
  ];
  
  const menu = Menu.buildFromTemplate(template);
  Menu.setApplicationMenu(menu);

  mainWindow.on('closed', () => mainWindow = null);
}

app.whenReady().then(() => {
  createWindow();
  
  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});
